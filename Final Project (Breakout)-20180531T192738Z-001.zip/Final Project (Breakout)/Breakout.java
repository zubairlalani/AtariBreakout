import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.*;
import javafx.scene.media.AudioClip;
import java.net.URL;
import javafx.application.Application;
import javafx.geometry.Rectangle2D;
import javafx.event.*;
import javafx.scene.input.*;
import javafx.scene.text.*;

public class Breakout extends Application implements EventHandler<InputEvent>
{
	GraphicsContext gc;
	Image paddle;
	Image ball;
	int paddleX = 0;
	int ballX = 0;
	int ballY = 100;
	int direction = 0;
	AnimateObjects animate;
	Canvas canvas;

	public static void main(String[] args)
	{
		launch();
	}
	public void start(Stage stage)
	{
		stage.setTitle("Breakout");
		Group root = new Group();
		canvas = new Canvas(800, 400);
		root.getChildren().add(canvas);
		Scene scene= new Scene(root);
		stage.setScene(scene);

		stage.show();

		gc=canvas.getGraphicsContext2D();
		paddle = new Image ( "paddle.jpg" );
		ball = new Image( "ball.jpg" );
		//gc.drawImage(paddle, 700, 100);

		animate = new AnimateObjects();
		animate.start();
		stage.show();

		scene.addEventHandler(KeyEvent.KEY_PRESSED, this);
	}

	public void handle(final InputEvent event)
	{
		if(((KeyEvent)event).getCode() == KeyCode.LEFT)               //input from user
			paddleX-=5;
		if(((KeyEvent)event).getCode() == KeyCode.RIGHT)
			paddleX+=5;
	}
	public class AnimateObjects extends AnimationTimer{
		public void handle(long now)
		{
			//if it hits bottom and does not hit either side and X is positive
				//ball will go up and right

			//else if ball hits bottom and does hit either side and X is negative
				//ball will go up and left

			//if ball hits right side and does not hits bottom or top and Y
				//ball will go left

			//if ball hits top and does not hit either side
				//ball will go down

			//if ball hits left and does not hit bottom or top
				//ball will go right
			if(ballY<canvas.getHeight() && direction == 0)
			{
				gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
				gc.drawImage(paddle, paddleX, 350); //create paddle image
				gc.drawImage(ball, ballX, ballY);
				ballX++;
				ballY++;
				Rectangle2D rectPad  = new Rectangle2D ( paddleX, 350, paddle.getWidth(), paddle.getHeight());  //creates rectangle around paddle
				Rectangle2D rectBall = new Rectangle2D ( ballX, ballY, ball.getWidth(), ball.getHeight() ); //creates rect around ball
				if(rectPad.intersects(rectBall))
					System.out.println("Hit");
				if(ballY==canvas.getHeight())
				{
					direction=1;
				}

			}
			else if(ballY>0 && direction == 1)
			{

				gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
				gc.drawImage(paddle, paddleX, 350); //create paddle image
				gc.drawImage(ball, ballX, ballY);
				ballX++;
				ballY--;
				Rectangle2D rectPad  = new Rectangle2D ( paddleX, 350, paddle.getWidth(), paddle.getHeight());  //creates rectangle around paddle
				Rectangle2D rectBall = new Rectangle2D ( ballX, ballY, ball.getWidth(), ball.getHeight() ); //creates rect around ball
				if(rectPad.intersects(rectBall))
					System.out.println("Hit");
				if(ballY==0)
				{
					direction=0;
				}

			}





			//gc.fillRect(ballX, ballY, ball.getWidth(), ball.getHeight() );


		}
	}

}